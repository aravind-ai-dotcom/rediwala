import SwiftUI
import FirebaseCore

@main
struct RediWalaVendorApp: App {

    init() {
        FirebaseApp.configure()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
